class Libro:
    def __init__(self, titulo, autor, precio, disponible):
        self.titulo = titulo
        self.autor = autor
        self.precio = precio
        self.disponibile = disponible

    def __str__(self):
        estado = "Disponible" if self.disponibile else "No disponible"
        return f"'{self.titulo}' de {self.autor} - ${self.precio:.2f} [{estado}]"


libros = [
    Libro("Cien años de soledad", "Gabriel García Márquez", 25.50, True),
    Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 30.00, False),
    Libro("La niña de Guatemala", "María Elena Walsh", 18.00, True),
    Libro("El principito", "Antoine de Saint-Exupéry", 12.50, True),
    Libro("Las aventuras de Alice en el Paíz de las maravillas", "Maria Jose de Perez" 22.00, True)
]


print("--- Lista Inicial de Libros ---")
for libro in libros:
    print(libro)


precio_total = sum(libro.precio for libro in libros)
print(f"\nPrecio total de los libros: ${precio_total:.2f}")


disponibles = sum(1 for libro in libros if libro.disponibile)
print(f"Cantidad de libros disponibles: {disponibles}")

 
nuevo_libro = Libro("Como encontrar paz", "Carlos Castaneda", 15.00, True)
libros.append(nuevo_libro)

print("\n--- Lista Actualizada (tras append) ---")
for libro in libros:
    print(libro)